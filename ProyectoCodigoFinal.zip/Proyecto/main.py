# --------- Inicio del programa ---------

from visualizador import VisualizadorArboles

if __name__ == "__main__":
    app = VisualizadorArboles()
    app.mainloop()